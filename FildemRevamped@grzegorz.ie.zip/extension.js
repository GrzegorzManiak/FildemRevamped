console.log("Hello, world!");
//# sourceMappingURL=extension.js.map