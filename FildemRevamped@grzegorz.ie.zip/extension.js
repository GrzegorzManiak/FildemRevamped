var lib;(()=>{var e={361:e=>{e.exports={misc:imports.misc,ui:imports.ui}}};var t={};function __webpack_require__(i){var n=t[i];if(n!==void 0)return n.exports;var r=t[i]={exports:{}};e[i](r,r.exports,__webpack_require__);return r.exports}(()=>{__webpack_require__.d=(e,t)=>{for(var i in t)if(__webpack_require__.o(t,i)&&!__webpack_require__.o(e,i))Object.defineProperty(e,i,{enumerable:true,get:t[i]})}})();(()=>{__webpack_require__.o=(e,t)=>Object.prototype.hasOwnProperty.call(e,t)})();(()=>{__webpack_require__.r=e=>{if(typeof Symbol!=="undefined"&&Symbol.toStringTag)Object.defineProperty(e,Symbol.toStringTag,{value:"Module"});Object.defineProperty(e,"__esModule",{value:true})}})();var i={};(()=>{"use strict";__webpack_require__.r(i);__webpack_require__.d(i,{EntryPoint:()=>EntryPoint});var e=__webpack_require__(361);const t={INFO:"INFO",WARN:"WARN",ERROR:"ERROR",LOG:"LOG"};const log_header=e=>{const t=new Date;return`[${e}: ${t.getHours()}:${t.getMinutes()}:${t.getSeconds()}:${t.getMilliseconds()}]`};const flog=(e,...t)=>{const i=log_header(e),n="font-weight: bold;";print(`%c${i} ${n}`,...t)};function _defineProperty(e,t,i){t=_toPropertyKey(t);if(t in e)Object.defineProperty(e,t,{value:i,enumerable:true,configurable:true,writable:true});else e[t]=i;return e}function _toPropertyKey(e){var t=_toPrimitive(e,"string");return typeof t==="symbol"?t:String(t)}function _toPrimitive(e,t){if(typeof e!=="object"||e===null)return e;var i=e[Symbol.toPrimitive];if(i!==void 0){var n=i.call(e,t||"default");if(typeof n!=="object")return n;throw new TypeError("@@toPrimitive must return a primitive value.")}return(t==="string"?String:Number)(e)}const n=e.misc.extensionUtils;const r=n.getCurrentExtension();const o=n.gettext;const a="fildem-revamped";class GlobalExtension{constructor(e){_defineProperty(this,"_gettext_domain",a);this._uuid=e;n.initTranslations(a);this._check_me()}static get_instance(){if(!GlobalExtension._instance)GlobalExtension._instance=new GlobalExtension(r.metadata.uuid);return GlobalExtension._instance}_check_me(){if(!r){flog("ERROR",o("Me is not defined!"));throw new Error(o("Me is not defined!"))}}enable(){flog("INFO","Enabling extension: ",r.metadata.uuid)}disable(){flog("WARN","Disabling extension: ",r.metadata.uuid)}}class EntryPoint{static init(e){flog("INFO","Initializing extension: ",e);return GlobalExtension.get_instance()}static enable(){GlobalExtension.get_instance().enable()}static disable(){GlobalExtension.get_instance().disable()}}})();lib=i})();
//# sourceMappingURL=extension.js.map

    /**
     * INJECTED BY COMP.TS SCRIPT
     */

    function init(meta) {
        global.log('Initializing extension');
        lib.EntryPoint.init(meta);
    };

    function enable() {
        global.log('Enabling extension');
        lib.EntryPoint.enable();
    };

    function disable() {
        global.log('Disabling extension');
        lib.EntryPoint.disable();
    };
