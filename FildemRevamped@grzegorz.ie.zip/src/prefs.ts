// -- https://github.com/gjsify/types 
//    All types are available here
//    npm install --save-dev @girs/adw-1 etc
import Gtk from '@girs/gtk-4.0';
import Adw from '@girs/adw-1';
import { flog } from './log';
